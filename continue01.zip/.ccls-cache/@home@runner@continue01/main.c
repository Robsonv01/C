#include <stdio.h>

int main(void) {
for(int i=1 ; i<=10 ;i++) {
  if(i == 5){
  continue;//pula o value of 5 
  }
  printf("%i\n",i);
} 
  printf("Final");
  return 0;
}