#include <stdio.h>

int main(void) {
 int matriz[] = {2,6,8,7,9};
int soma = 0;
  double media;

  
  for(int i = 0; i < 5; i++){
    soma = soma + matriz[i];
  }
  media = soma/5;

  printf("\nA média dos elementos da matriz é: %lf", media);

  
  return 0;
}