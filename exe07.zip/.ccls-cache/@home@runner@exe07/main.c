#include <stdio.h>

int main(void) {
int num1;


  printf("Digite o primeiro número: ");
  scanf("%d",&num1);
if (num1 % 2 == 0){
                printf("é par %d", num1);
} else {
printf("é impar %d", num1);
}
                
  return 0;
}