#include <stdio.h>

int main(void) {
  int num;
  for(int i = 1; i <= 10; i++){
    printf("Informe um número: ");
    scanf("%i", &num);

    if(num % 2 != 0)
      continue;
printf("Número : %i\n", num);
  }
  return 0;
}