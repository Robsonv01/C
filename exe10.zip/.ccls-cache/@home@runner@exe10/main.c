#include <stdio.h>

int main(void) {
int num1, num2;


  printf("Digite o primeiro número: ");
  scanf("%i",&num1);
  printf("Digite o segundo número: ");
  scanf("%i",&num2);
if (num1 > 0 || num2 > 0){
                printf("\nUns dos numero é positivo");

          
} else  {
printf("\nNenhum dos numero é positivo");
  
}

  return 0;
}