#include <stdio.h>

int main(void) {
for(int i=1 ; i<=10 ;i++) {
  if(i == 5)//sai do bloco for
    break;
  printf("%i\n",i);
} 
  printf("Final");
  return 0;
}