#include <stdio.h>

int main(void) {
  double num1, quadrado;
  printf("Digite o primeiro número: ",num1);
  scanf("%lf", &num1);
  quadrado = num1 * num1;
  printf("O quadrado do número é: %lf" , quadrado);
  
  return 0;
}