#include <stdio.h>

int main(void) {
  double num1, num2;

  printf("Digite o primeiro número: ");
  scanf("%lf", &num1);
  printf("Digite o segundo número: ");
  scanf("%lf", &num2);
  if (num1 == num2) {
    printf("São iguais: ");
  } else {
    printf("Não sao iguais ");
  }

  return 0;
}