#include <stdio.h>

int main(void) {
int num1, num2, num3;


  printf("Digite o primeiro número: ");
  scanf("%i",&num1);
  printf("Digite o segundo número: ");
  scanf("%i",&num2);
  printf("Digite o terceiro número: ");
  scanf("%i",&num3);
if (num1 < 0 && num2 < 0 && num3 < 0 ){ 
                printf("\nTodos os numeros sao negativos");


} else  {
printf("\nPelo menos um dos numeros e positivo");

}

  return 0;
}