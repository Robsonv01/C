#include <stdio.h>

int main(void) {
  
int i = 2;
  while (i <= 20) {
    printf("%i\n", i);
    i += 2;
  }
  return 0;
}