#include <stdio.h>

int main(void) {
  int num1;


  printf("Digite o primeiro número: ");
  scanf("%i",&num1);

if (num1 > 0){
  printf("O número é positivo");
} else if (num1 < 0) {
   printf("O número é negativo");
  } else {
  printf("O número é zero");
}
  return 0;
}