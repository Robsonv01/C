#include <stdio.h>

int main(void) {
  double num1, num2;


  printf("Digite o primeiro número: ");
  scanf("%lf", &num1);
  printf("Digite o segundo número: ");
  scanf("%lf", &num2);

  if(num1>num2){
    printf("O maior número é: %lf", num1);
  } else {
    printf("O maior número é: %lf", num2);
  }
  return 0;
}