#include <stdio.h>

int main(void) {
 char letra;
  printf("Infome uma letra: ");
  scanf("%c", &letra);
switch(letra){
  case 'a':
    

  case 'e':
    

    case 'o':

    
      case 'u':
    
     
        case 'i':
           printf("A letra é uma vogal");
        break;
 
    default:
      printf("É uma consoante");
}
  return 0;
}