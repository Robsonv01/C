#include <stdio.h>

int main(void) {
  double num1, num2, soma;


  printf("Digite o primeiro número: ");
  scanf("%lf", &num1);
  printf("Digite o segundo número: ");
  scanf("%lf", &num2);

  soma = num1 + num2;
  printf("A soma dos números é: %lf", soma);
  return 0;
}