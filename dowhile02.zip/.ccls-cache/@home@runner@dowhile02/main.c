#include <stdio.h>

int main(void) {
  int num;
  
  do {
    printf("Digite um número entre 1 e 5: ");
    scanf("%d", &num);
  } while (num < 1 || num > 5);
  printf("Numero esta no intervalo (1-5)\n  Voce informou o numero: %d", num);
  
  return 0;
}