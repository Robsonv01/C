#include <stdio.h>

int main(void) {
  char nome[] = "João";
  int idade = 25;
  printf("Meu nome é %s e tenho %i anos.", nome, idade);

  return 0;
}
