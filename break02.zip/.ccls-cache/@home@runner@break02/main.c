#include <stdio.h>

int main(void) {
int num1, soma = 0;

  while(1){
    printf("Digite um número: ");

    scanf("%d", &num1);

    soma = soma + num1;

    if(soma > 50)
      break;
    
    }
printf("A soma execedeu 50! Soma: %i", soma);
  

  
  return 0;
}