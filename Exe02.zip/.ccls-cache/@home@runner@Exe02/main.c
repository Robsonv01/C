#include <stdio.h>

int main(void) {
  const double pi = 3.141592;
  printf("0 valor de PI é: %lf", pi);
  return 0;
}
