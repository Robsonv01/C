#include <stdio.h>

int main(void) {
  int num1;


  printf("Digite o primeiro número: ");
  scanf("%i",&num1);
  
if (num1 >= 10 && num1 <= 20){
  printf("O número está entre 10 e 20");
} else {
  printf("O número não está entre 10 e 20");
}
  return 0;
}