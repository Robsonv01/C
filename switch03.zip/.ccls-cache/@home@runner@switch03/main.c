#include <stdio.h>

int main(void) {
  int escolha;
  const double pi = 3.14;
  double lado, area, base, altura, raio;
  printf("Escolha uma forma geometrica:\n ");
  printf("1 - Quadrado\n");
  printf("2 - Retangulo\n");
  printf("3 - Circulo\n");
  scanf("%d", &escolha);

    switch(escolha) {
      case 1:
        printf("Informe o lado do Quadrado\n");
        scanf("%lf", &lado);
        area = lado * lado;
        printf("A area do Quadrado é: %lf" , area);
        break;
      case 2:
        printf("Informe a base do Triangulo\n");
        scanf("%lf", &base);
        printf("Informe a altura do Triangulo\n");
        scanf("%lf", &altura);
        
        area = base * altura * 0.5;
        printf("A area do Triangulo é: %lf" , area);
    
        break;
      case 3:
        printf("Informe o raio do Circulo\n");
        scanf("%lf", &raio);

        area = pi * raio * raio;

        printf("A area do Circulo é: %lf" , area);
        break;
      default:
        printf("Opcao invalida\n");
    }
    
  
  return 0;
}