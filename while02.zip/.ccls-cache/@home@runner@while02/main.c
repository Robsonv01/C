#include <stdio.h>

int main(void) {
  int num, certo = 10;
  printf("Digite um número: ");
  scanf("%d", &num);
  while(num != certo){
    printf("Você errou, tente novamente: ");
  scanf("%d" , &num);
  } 
  printf("Você acertou!");
  scanf("%d", &num);
 

  return 0;
}