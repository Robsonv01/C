#include <stdio.h>

int main(void) {
  const double pi = 3.141592;
  double raio, area;
  printf("0 valor de PI é: %lf", pi);
  printf("\nDigite o valor do raio: ");
   scanf("%lf",&raio);

  area = pi * raio*raio;
  
  printf("A área do círculo é: %lf", area);
    
  return 0;
}
