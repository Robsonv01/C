#include <stdio.h>

int main(void) {
 int matriz[] = {2,6,8,7,9};

  for(int i = 0; i < 5; i++){
    printf("%d\n", matriz[i]);
    
  }
  printf("A soma dos elementos da matriz é: %i", matriz);

  return 0;
}