#include <stdio.h>

int main(void) {
  int i = 1;

  do {
   printf("%i\n", i);
    i++;
  } while (i <= 10);
  return 0;
}