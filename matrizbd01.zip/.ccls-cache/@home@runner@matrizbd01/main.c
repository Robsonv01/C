#include <stdio.h>

int main(void) {
 int matriz[3][3] = {{2,6,8}, {15,22,40},{3,18,98}};
int soma = 0;


  for(int i = 0; i < 3; i++)
    for(int j = 0; j < 3; j++) {
      printf("%i ", matriz[i][j]);
    soma = soma + matriz[i][j];
  }
printf("\nA soma dos valores da matriz é: %i ", soma);




  return 0;
}