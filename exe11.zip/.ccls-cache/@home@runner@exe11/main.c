#include <stdio.h>

int main(void) {
  int num1;


  printf("Digite o primeiro número: ");
  scanf("%i",&num1);

if (!(num1 >= 5 && num1 <= 15)){
  printf("O número NÃO está entre 5 e 15");
} else {
  printf("O número está entre 5 e 15");
}
  return 0;
}